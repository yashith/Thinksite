A Pen created at CodePen.io. You can find this one at http://codepen.io/darcyvoutt/pen/ogPrpK.

 Was inspired to code up a timeline based on some Dribbble shots that I seen.